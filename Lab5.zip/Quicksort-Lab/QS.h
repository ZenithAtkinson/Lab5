/*
* QSInterface.h
*
*  Created on: May 1, 2014
*  Last Updated on: March 30, 2015
*/

#pragma once
#include "QSInterface.h"




class QS
{
		protected:
	int valueCount, arrayCapacity;
	int* int_array;

public:
	QS() {}
	~QS() {}


	void sortAll() override;


	int medianOfThree(int left, int right) override;


	int partition(int left, int right, int pivotIndex) override;

	
	string getArray() const override;


	int getSize() const override;

	bool addToArray(int value) override;


	bool createArray(int capacity) override;


	void clear() override;
};
