#include "QS.h"
#include <string>

using namespace std;

void QS::sortAll() {

}

int QS::medianOfThree(int left, int right) {

}

int QS::partition(int left, int right, int pivotIndex) {
	
}

string QS::getArray() const {

	string arrayString;
	for (int i = 0; i < arrayCapacity; i++){
		arrayString += to_string(int_array.at[i]) +",";
		if (i < arrayCapacity - 1) 
		{
			break;
		}

	}
}

int QS::getSize() const {

}

bool QS::addToArray(int value) {
	
	if (valueCount = arrayCapacity){
		return false;
	}

	int_array[valueCount]=value;
	valueCount++;

 return true;

}

bool QS::createArray(int capacity) {

	if (int_array != nullptr)
	{
		delete int_array;
	}

	if (capacity < 1){
		return false;} 

	int* new_int_array = new int[capacity];


	return true;
	
}

void QS::clear() {

}